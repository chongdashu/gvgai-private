package culim.ai.components;

import core.game.StateObservation;
import culim.ai.AIUtils;
import ontology.Types.WINNER;

public class QLearningReward
{
	
	public static double getReward(QLearningState state)
	{
		float width =  state.gridWidth;
		float height =  state.gridHeight;
		double max = (width*height)*(width*height);
		
		// Get the reward for a given q-learning state.
		double reward = 0.7 * state.genericReward 
//						+ 0.1 * (state.meanNpcDistance/max)
						+ 0.3 * (1-state.meanMovableDistances/max);
						
		
		return reward;
		
	}
	
	public static double getGenericReward(StateObservation stateObs)
	{
		// Winner
		if (stateObs.isGameOver())
		{
			double gameWinnerScore = 0;
			WINNER gameWinner = stateObs.getGameWinner();
			
			if (gameWinner == WINNER.PLAYER_WINS)
			{
				gameWinnerScore = 1;
			}
			else if (gameWinner == WINNER.NO_WINNER)
			{
				gameWinnerScore = 0;
			}
			else if (gameWinner == WINNER.PLAYER_LOSES)
			{
				gameWinnerScore = -1; 
			}
			else if (gameWinner == WINNER.PLAYER_DISQ)
			{
				gameWinnerScore = -1;
			}
			
			return gameWinnerScore;
		}
		else
		{
			return stateObs.getGameScore()/10;
		}
	}

}

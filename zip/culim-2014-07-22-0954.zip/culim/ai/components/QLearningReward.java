package culim.ai.components;

import culim.ai.AIUtils;
import ontology.Types.WINNER;

public class QLearningReward
{
	
	public static double getReward(QLearningState state)
	{
		float width =  state.gridWidth;
		float height =  state.gridHeight;
		double max = (width*height)*(width*height);
		
		// Get the reward for a given q-learning state.
		return state.genericReward 
				+ (state.meanNpcDistance/max);
	}

}
